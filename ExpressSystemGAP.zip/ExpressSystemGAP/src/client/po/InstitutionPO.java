package client.po;

import java.io.Serializable;

public class InstitutionPO implements Serializable {

}
