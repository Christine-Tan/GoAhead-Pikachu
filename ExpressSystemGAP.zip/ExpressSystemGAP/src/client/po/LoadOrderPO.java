package client.po;

import java.io.Serializable;

public class LoadOrderPO implements Serializable {

}
