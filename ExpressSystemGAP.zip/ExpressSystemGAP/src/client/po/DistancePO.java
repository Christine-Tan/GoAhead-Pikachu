package client.po;

import java.io.Serializable;

public class DistancePO implements Serializable {

}
