package client.po;

import java.io.Serializable;

public class SalaryPO implements Serializable {

}
