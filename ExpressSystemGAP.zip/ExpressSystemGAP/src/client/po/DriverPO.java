package client.po;

import java.io.Serializable;

public class DriverPO implements Serializable {

}
