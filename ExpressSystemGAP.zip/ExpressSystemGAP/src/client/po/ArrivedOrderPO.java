package client.po;

import java.io.Serializable;

public class ArrivedOrderPO implements Serializable {

}
