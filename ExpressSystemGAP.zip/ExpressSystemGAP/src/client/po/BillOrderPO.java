package client.po;

import java.io.Serializable;

public class BillOrderPO implements Serializable {

}
