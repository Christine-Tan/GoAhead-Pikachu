package client.po;

import java.io.Serializable;

public class UserPO implements Serializable {

}
