package client.po;

import java.io.Serializable;

public class PricePO implements Serializable {

}
