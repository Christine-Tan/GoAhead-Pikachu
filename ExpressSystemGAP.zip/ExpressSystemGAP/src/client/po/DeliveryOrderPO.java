package client.po;

import java.io.Serializable;

public class DeliveryOrderPO implements Serializable {

}
