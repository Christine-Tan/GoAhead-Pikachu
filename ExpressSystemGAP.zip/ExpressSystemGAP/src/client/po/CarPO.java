package client.po;

import java.io.Serializable;

public class CarPO implements Serializable {

}
