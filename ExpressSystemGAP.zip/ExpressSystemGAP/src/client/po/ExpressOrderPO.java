package client.po;

import java.io.Serializable;

public class ExpressOrderPO implements Serializable {

}
