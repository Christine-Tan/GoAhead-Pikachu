package client.blservice.orderblservice;

public interface ArrivedOrderService {
	
}
