package client.blservice.inventoryblservice;

public interface InventoryService {

}
