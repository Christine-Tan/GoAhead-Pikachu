package client.blservice.loginblservice;

public interface LoginService {

}
