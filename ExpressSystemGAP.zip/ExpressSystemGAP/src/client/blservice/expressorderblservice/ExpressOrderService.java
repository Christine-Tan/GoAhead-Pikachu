package client.blservice.expressorderblservice;

public interface ExpressOrderService {

}
