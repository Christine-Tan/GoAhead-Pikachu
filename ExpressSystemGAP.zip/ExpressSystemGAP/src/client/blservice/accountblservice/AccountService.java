package client.blservice.accountblservice;

public interface AccountService {

}
