package client.blservice.logblservice;

public interface LogService {

}
