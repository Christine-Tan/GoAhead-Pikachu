package client.dataservice.expressorderdataservice;

public interface ExpressOrderDataService {

}
