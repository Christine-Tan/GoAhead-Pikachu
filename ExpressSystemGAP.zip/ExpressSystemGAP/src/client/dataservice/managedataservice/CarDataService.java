package client.dataservice.managedataservice;

import client.vo.CarVO;

public interface CarDataService {

}
