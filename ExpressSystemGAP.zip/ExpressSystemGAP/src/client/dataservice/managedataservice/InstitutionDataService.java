package client.dataservice.managedataservice;

public interface InstitutionDataService {

}
