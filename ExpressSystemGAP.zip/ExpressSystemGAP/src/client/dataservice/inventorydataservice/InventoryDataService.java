package client.dataservice.inventorydataservice;

public interface InventoryDataService {

}
