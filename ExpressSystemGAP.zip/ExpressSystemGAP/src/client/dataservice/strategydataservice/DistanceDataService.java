package client.dataservice.strategydataservice;

public interface DistanceDataService {

}
