package client.dataservice.strategydataservice;


public interface SalaryDataService {

}
