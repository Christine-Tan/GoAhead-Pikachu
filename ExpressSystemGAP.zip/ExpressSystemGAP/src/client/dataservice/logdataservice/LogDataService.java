package client.dataservice.logdataservice;

public interface LogDataService {

}
