package client.dataservice.accountdataservice;

public interface AccountDataService {

}
