package client.dataservice.orderdataservice;

public interface StockinOrderDataService {

}
