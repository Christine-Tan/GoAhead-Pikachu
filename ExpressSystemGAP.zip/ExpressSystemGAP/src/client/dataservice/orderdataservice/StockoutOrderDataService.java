package client.dataservice.orderdataservice;

public interface StockoutOrderDataService {

}
