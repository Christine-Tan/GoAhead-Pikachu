package client.dataservice.userdataservice;

public interface UserDataService {

}
