package client.vo;

public class ArrivedOrderVO {

}
