package client.vo;

public class CityVO {

}
