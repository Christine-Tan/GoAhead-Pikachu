package client.vo;

public class StockoutOrderVO {

}
