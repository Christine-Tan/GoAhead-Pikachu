package client.vo;

public class ExpressOrderVO {

}
