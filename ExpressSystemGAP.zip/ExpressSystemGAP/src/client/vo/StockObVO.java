package client.vo;

public class StockObVO {

}
