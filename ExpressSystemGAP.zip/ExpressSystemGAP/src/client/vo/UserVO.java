package client.vo;

public class UserVO {

}
