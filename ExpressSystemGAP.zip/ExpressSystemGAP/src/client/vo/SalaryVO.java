package client.vo;

public class SalaryVO {

}
