package client.vo;

public class LogVO {

}
