package client.vo;

public class PriceVO {

}
