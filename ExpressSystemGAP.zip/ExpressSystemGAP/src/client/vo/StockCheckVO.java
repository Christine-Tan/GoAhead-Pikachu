package client.vo;

public class StockCheckVO {

}
