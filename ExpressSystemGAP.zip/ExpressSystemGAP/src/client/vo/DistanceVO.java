package client.vo;

public class DistanceVO {

}
