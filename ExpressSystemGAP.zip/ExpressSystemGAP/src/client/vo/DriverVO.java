package client.vo;

public class DriverVO {

}
