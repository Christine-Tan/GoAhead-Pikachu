package client.vo;

public class InstitutionVO {

}
