package client.vo;

public class LoadOrderVO {

}
