package client.vo;

public class CarVO {

}
