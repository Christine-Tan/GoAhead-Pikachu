package client.vo;

public class DeliveryOrderVO {

}
